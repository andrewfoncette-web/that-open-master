import { IProject, Project } from "./Project"

export class ProjectsManager {
    list: Project[] = []
    ui: HTMLElement
    defaultData: IProject

    constructor(container: HTMLElement) {
        this.ui = container
        this.defaultData = {
            name: "Default Name" as string,
            description: "Default Description" as string,
            userRole: "developer",
            status: "active",
            finishDate: new Date()
        }
    }

    newProject(data: IProject) {
        const project = new Project(this.defaultData)
        this.ui.append(project.ui)
        this.list.push(project)
        return project
    }

}